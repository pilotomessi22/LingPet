import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Truck,
  CreditCard,
  CheckCircle2,
  Copy,
  Check,
  Package,
  MapPin,
  RotateCcw,
  Sparkles,
} from 'lucide-react';
import {
  CartItem,
  ShippingAddress,
  calculateOrderTotals,
  formatCurrency,
  formatDropshippingOrderPayload,
} from '../utils/storeLogic.ts';
import { US_STATES, PRODUCT_SUPPLIER_CATALOG } from '../data/storeData.ts';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  appliedPromo: string;
  onClearCart: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  appliedPromo,
  onClearCart,
}) => {
  const [address, setAddress] = useState<ShippingAddress>({
    fullName: '',
    streetAddress: '',
    aptOrSuite: '',
    city: '',
    state: 'FL',
    zipCode: '',
    email: '',
    phone: '',
    deliveryMethod: 'shipping',
  });

  const [paymentMethod, setPaymentMethod] = useState<'card' | 'apple_pay' | 'paypal'>('card');
  const [deliveryOption, setDeliveryOption] = useState<'usps_ground' | 'usps_priority'>('usps_ground');
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [copiedPayload, setCopiedPayload] = useState(false);

  if (!isOpen) return null;

  const baseCalculations = calculateOrderTotals(items, appliedPromo, 'shipping');

  const shippingCost =
    deliveryOption === 'usps_priority'
      ? 9.95
      : baseCalculations.freeShippingQualified
      ? 0
      : baseCalculations.shipping;

  const finalTotal = Number(
    (baseCalculations.total - baseCalculations.shipping + shippingCost).toFixed(2)
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newOrderId = `LP-AUS-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderId(newOrderId);

    // Save order into localStorage for the Admin Panel
    try {
      const existingOrdersRaw = localStorage.getItem('ling_admin_orders');
      const existingOrders = existingOrdersRaw ? JSON.parse(existingOrdersRaw) : [];
      const newAdminOrder = {
        id: `ord-${Date.now()}`,
        orderNumber: newOrderId,
        date: 'Hoje, agora mesmo',
        customerName: address.fullName,
        customerEmail: address.email,
        customerPhone: address.phone,
        shippingAddress: {
          street: address.streetAddress + (address.aptOrSuite ? `, ${address.aptOrSuite}` : ''),
          city: address.city,
          state: address.state,
          zip: address.zipCode,
          country: 'United States',
        },
        items: items.map((it) => {
          const supMeta = PRODUCT_SUPPLIER_CATALOG[it.sku.split('-')[0]] || {
            supplier: 'CJ Dropshipping',
            supplierSku: it.sku,
            supplierUrl: 'https://cjdropshipping.com',
          };
          return {
            sku: it.sku,
            name: it.name,
            size: it.size,
            color: it.color,
            quantity: it.quantity,
            unitPrice: it.price,
            supplierCost: it.supplierCost,
            supplier: supMeta.supplier,
            supplierSku: supMeta.supplierSku || it.sku,
            supplierUrl: supMeta.supplierUrl || 'https://cjdropshipping.com',
          };
        }),
        totalUsd: finalTotal,
        supplierCostUsd: items.reduce((acc, curr) => acc + curr.supplierCost * curr.quantity, 0),
        profitUsd: Math.max(0, finalTotal - items.reduce((acc, curr) => acc + curr.supplierCost * curr.quantity, 0)),
        paymentGateway: 'Stripe (Credit Card / Apple Pay)',
        paymentStatus: 'Paid',
        fulfillmentStatus: 'Aguardando Despacho',
      };

      localStorage.setItem('ling_admin_orders', JSON.stringify([newAdminOrder, ...existingOrders]));
      window.dispatchEvent(new Event('storage'));
    } catch (err) {
      console.error('Error saving order to localStorage:', err);
    }

    setOrderComplete(true);
    onClearCart();
  };

  const supplierPayload = formatDropshippingOrderPayload(
    orderId || 'LP-PREVIEW',
    items,
    address
  );

  const handleCopyPayload = () => {
    navigator.clipboard.writeText(supplierPayload);
    setCopiedPayload(true);
    setTimeout(() => setCopiedPayload(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      {/* Backdrop */}
      <div
        onClick={onClose}
        className="fixed inset-0 bg-black/70 backdrop-blur-xs transition-opacity"
      />

      {/* Modal Dialog */}
      <div className="relative bg-white rounded-2xl max-w-2xl w-full p-5 sm:p-8 shadow-2xl z-10 max-h-[92vh] overflow-y-auto my-6 border border-gray-200">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
          aria-label="Close checkout"
        >
          <X size={20} />
        </button>

        {!orderComplete ? (
          <div>
            {/* Header */}
            <div className="pb-4 border-b border-gray-200">
              <div className="flex items-center gap-2 text-xs font-black uppercase text-[#E31837] tracking-wider">
                <ShieldCheck size={16} />
                <span>256-Bit Encrypted US Checkout</span>
              </div>
              <h2 className="text-2xl font-black text-[#002855] tracking-tight mt-1">
                Express Checkout · Ling Petshop
              </h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Official US Online Store · Fast Tracked USPS Shipping to All 50 States
              </p>
            </div>

            <form onSubmit={handleSubmit} className="mt-6 space-y-6">
              {/* Delivery Preference */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider text-gray-700 block mb-2">
                  1. Choose USPS Shipping Method
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div
                    onClick={() => setDeliveryOption('usps_ground')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      deliveryOption === 'usps_ground'
                        ? 'border-[#002855] bg-blue-50/50 ring-2 ring-[#002855]'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                        <Truck size={14} className="text-[#002855]" />
                        USPS Ground Advantage
                      </span>
                      <span className="text-xs font-black text-emerald-700">
                        {baseCalculations.freeShippingQualified ? 'FREE' : '$4.95'}
                      </span>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">
                      3 - 5 business days with live postal tracking
                    </p>
                  </div>

                  <div
                    onClick={() => setDeliveryOption('usps_priority')}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      deliveryOption === 'usps_priority'
                        ? 'border-[#002855] bg-blue-50/50 ring-2 ring-[#002855]'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-gray-900 flex items-center gap-1.5">
                        <Truck size={14} className="text-[#E31837]" />
                        USPS Priority Express
                      </span>
                      <span className="text-xs font-black text-gray-900">$9.95</span>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">
                      2 - 3 business days expedited priority queue
                    </p>
                  </div>
                </div>
              </div>

              {/* Shipping Address Inputs */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider text-gray-700 block mb-2">
                  2. US Delivery Address
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="sm:col-span-2">
                    <label className="block text-gray-600 font-bold mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={address.fullName}
                      onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-gray-600 font-bold mb-1">
                      Street Address
                    </label>
                    <input
                      type="text"
                      required
                      value={address.streetAddress}
                      onChange={(e) => setAddress({ ...address, streetAddress: e.target.value })}
                      placeholder="e.g. 1402 S Congress Ave"
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">
                      Apt / Suite / Unit (Optional)
                    </label>
                    <input
                      type="text"
                      value={address.aptOrSuite || ''}
                      onChange={(e) => setAddress({ ...address, aptOrSuite: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">City</label>
                    <input
                      type="text"
                      required
                      value={address.city}
                      onChange={(e) => setAddress({ ...address, city: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">State</label>
                    <select
                      value={address.state}
                      onChange={(e) => setAddress({ ...address, state: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 bg-white focus:outline-none focus:border-[#002855]"
                    >
                      {US_STATES.map((st) => (
                        <option key={st.code} value={st.code}>
                          {st.code} - {st.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">ZIP Code (5 Digits)</label>
                    <input
                      type="text"
                      required
                      pattern="[0-9]{5}"
                      value={address.zipCode}
                      onChange={(e) => setAddress({ ...address, zipCode: e.target.value })}
                      placeholder="78704"
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">Email</label>
                    <input
                      type="email"
                      required
                      value={address.email}
                      onChange={(e) => setAddress({ ...address, email: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>

                  <div>
                    <label className="block text-gray-600 font-bold mb-1">Phone (for Tracking SMS)</label>
                    <input
                      type="tel"
                      required
                      value={address.phone}
                      onChange={(e) => setAddress({ ...address, phone: e.target.value })}
                      className="w-full p-2.5 rounded-lg border border-gray-300 focus:outline-none focus:border-[#002855]"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method Selector */}
              <div>
                <label className="text-xs font-black uppercase tracking-wider text-gray-700 block mb-2">
                  3. Payment Method
                </label>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-all ${
                      paymentMethod === 'card'
                        ? 'border-[#002855] bg-blue-50 text-[#002855] ring-2 ring-[#002855]'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    💳 Credit Card
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple_pay')}
                    className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-all ${
                      paymentMethod === 'apple_pay'
                        ? 'border-black bg-gray-50 text-black ring-2 ring-black'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300'
                    }`}
                  >
                     Apple Pay
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('paypal')}
                    className={`p-2.5 rounded-xl border text-center font-bold cursor-pointer transition-all ${
                      paymentMethod === 'paypal'
                        ? 'border-[#0070BA] bg-blue-50 text-[#0070BA] ring-2 ring-[#0070BA]'
                        : 'border-gray-200 text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    🅿 PayPal
                  </button>
                </div>
              </div>

              {/* Order Summary & Submit Button */}
              <div className="bg-[#F8F9FA] p-4 rounded-xl border border-gray-200 space-y-2 text-xs">
                <div className="flex justify-between text-gray-600">
                  <span>Subtotal ({items.reduce((a, c) => a + c.quantity, 0)} items)</span>
                  <span className="font-bold text-gray-900">{formatCurrency(baseCalculations.subtotal)}</span>
                </div>

                {baseCalculations.repeatDeliverySavings > 0 && (
                  <div className="flex justify-between text-emerald-700 font-bold">
                    <span>Repeat Delivery (35% OFF)</span>
                    <span>-{formatCurrency(baseCalculations.repeatDeliverySavings)}</span>
                  </div>
                )}

                {baseCalculations.promoDiscount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-bold">
                    <span>Promo ({baseCalculations.appliedPromo})</span>
                    <span>-{formatCurrency(baseCalculations.promoDiscount)}</span>
                  </div>
                )}

                <div className="flex justify-between text-gray-600">
                  <span>Shipping</span>
                  <span className="font-bold text-gray-900">
                    {shippingCost === 0 ? 'FREE' : formatCurrency(shippingCost)}
                  </span>
                </div>

                <div className="pt-2 border-t border-gray-200 flex justify-between items-baseline">
                  <span className="text-sm font-black text-gray-900">Total Charged</span>
                  <span className="text-xl font-black text-[#002855]">
                    {formatCurrency(finalTotal)}
                  </span>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-[#E31837] hover:bg-[#c9142e] text-white font-black text-sm py-4 rounded-full shadow-lg transition-transform hover:scale-[1.01] active:scale-[0.99] cursor-pointer uppercase tracking-wider"
              >
                Place Order · {formatCurrency(finalTotal)}
              </button>
            </form>
          </div>
        ) : (
          /* Order Complete Confirmation with Dropship Exporter */
          <div className="text-center py-6 space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <CheckCircle2 size={36} />
            </div>

            <div>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase px-2.5 py-1 rounded-full">
                Order Confirmed · Payment Successful
              </span>
              <h2 className="text-2xl font-black text-[#002855] tracking-tight mt-2">
                Thank You, {address.fullName.split(' ')[0]}!
              </h2>
              <p className="text-xs text-gray-500 mt-1">
                Confirmation #{orderId} has been sent to <strong>{address.email}</strong>.
              </p>
            </div>

            {/* US Postal Warehouse Dispatch Summary */}
            <div className="bg-blue-50/60 p-4 rounded-xl border border-blue-100 text-left text-xs space-y-2">
              <div className="flex items-center gap-2 text-[#002855] font-bold">
                <Truck size={16} className="text-[#E31837]" />
                <span>
                  {deliveryOption === 'usps_priority'
                    ? 'Dispatching via USPS Priority Express (2-3 Business Days)'
                    : 'Dispatching via USPS Ground Advantage from US Fulfillment Center'}
                </span>
              </div>
              <p className="text-gray-600">
                Estimated Delivery: <strong>2 - 4 Business Days</strong>. Live USPS postal tracking number will be sent via SMS to {address.phone} and email to {address.email}.
              </p>
            </div>

            {/* STORE OWNER SECTION: 1-Click Dropship Supplier Payload */}
            <div className="mt-6 pt-6 border-t border-gray-200 text-left">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-xs font-black uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                    <Package size={14} />
                    Store Owner Dropship Fulfillment Payload
                  </h4>
                  <p className="text-[11px] text-gray-500">
                    Copy and send this directly to CJ Dropshipping / Zendrop to ship to the customer:
                  </p>
                </div>
                <button
                  onClick={handleCopyPayload}
                  className="bg-amber-400 hover:bg-amber-500 text-stone-900 font-bold text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copiedPayload ? (
                    <>
                      <Check size={14} className="text-emerald-800" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy size={14} />
                      <span>Copy Payload</span>
                    </>
                  )}
                </button>
              </div>

              <pre className="mt-2 p-3 bg-gray-900 text-emerald-400 rounded-xl text-[11px] font-mono overflow-x-auto max-h-48 border border-gray-800">
                {supplierPayload}
              </pre>

              <div className="mt-3 flex items-center justify-between text-xs font-bold text-gray-700 bg-gray-50 p-3 rounded-lg border border-gray-200">
                <span>Estimated Store Net Margin:</span>
                <span className="text-emerald-700 font-black">
                  +{formatCurrency(baseCalculations.totalEstimatedProfit)} Profit
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="mt-4 bg-[#002855] text-white font-bold text-xs px-8 py-3 rounded-full hover:bg-[#001e44] transition-colors cursor-pointer"
            >
              Back to Storefront
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
